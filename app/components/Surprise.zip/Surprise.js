export default function Surprise({ onBack }) {
  return (
    <div className="relative w-full h-screen">

      {/* Background */}
      <img
        src="/bg.jpg"
        className="absolute w-full h-full object-cover"
      />

      {/* Overlay */}
      <div className="absolute w-full h-full bg-black/40 flex flex-col items-center justify-center text-white text-center px-4">
        
        <button
          onClick={onBack}
          className="absolute top-5 left-5 bg-white/20 px-4 py-2 rounded-lg"
        >
          ← Back
        </button>

        <h1 className="fall-text text-4xl md:text-6xl font-serif mb-4">
  Happy Birthday da Thangapulla ❤️
</h1>

        <p>I hope this little gift will make you happy ✨</p>
        <p className="mt-2">Enaku nee romba mukkiyam 💕</p>

      </div>
    </div>
  );
}