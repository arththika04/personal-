export default function Hero({ onOpen }) {
  return (
    <div className="h-screen flex flex-col items-center justify-center bg-pink-200 text-center overflow-hidden">
      
      <h1 className="text-4xl text-white mb-6 font-serif">
        Happy Birthday 💖
      </h1>

      {/* Envelope */}
      <div className="relative">
        <img
  src="/envelope.png"
  className="w-80 md:w-[420px] cursor-pointer z-10 relative hover:scale-105 transition duration-300"
  onClick={onOpen}
/>

        {/* Film strip animation */}
        <div className="film-strip">
          <img src="/1.jpg" />
          <img src="/2.jpg" />
          <img src="/3.jpg" />
          <img src="/4.jpg" />
        </div>
      </div>

      <p className="mt-4 text-gray-700">
        Click the seal to open 💌
      </p>
    </div>
  );
}