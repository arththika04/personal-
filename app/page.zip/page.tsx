"use client";

import { useState } from "react";

import Hero from "./components/Hero";
import Gallery from "./components/Gallery";
import Message from "./components/Message";
import Surprise from "./components/Surprise";

export default function Home() {
  const [password, setPassword] = useState("");
  const [unlocked, setUnlocked] = useState(false);
  const [toast, setToast] = useState(false);

  const [envelopeOpened, setEnvelopeOpened] = useState(false);

  const correctPassword = "0414";

  const handleNumber = (num: string) => {
    if (password.length < 4) {
      setPassword(password + num);
    }
  };

  const checkPassword = () => {
    if (password === correctPassword) {
      setUnlocked(true);
    } else {
      setToast(true);

      setTimeout(() => {
        setToast(false);
      }, 2500);

      setPassword("");
    }
  };

  const clearPassword = () => {
    setPassword("");
  };

  return (
    <main>

      {/* WRONG PASSWORD TOAST */}
      {toast && (
        <div className="fixed top-10 left-1/2 -translate-x-1/2 bg-red-500 text-white px-6 py-3 rounded-xl shadow-xl z-50">
          You are not the correct person ❌
        </div>
      )}

      {/* PASSWORD SCREEN */}
      {!unlocked ? (

        <div className="h-screen w-full bg-pink-100 flex items-center justify-center">

          <div className="bg-pink-200 p-8 rounded-3xl shadow-2xl text-center w-[320px]">

            {/* PROFILE IMAGE */}
            <img
              src="/couple.jpg"
              className="w-28 h-28 rounded-full mx-auto object-cover border-4 border-white mb-6"
            />

            {/* PASSWORD DISPLAY */}
            <div className="bg-white rounded-xl h-14 flex items-center justify-center text-3xl tracking-[10px] mb-6">
              {password.replace(/./g, "•")}
            </div>

            {/* NUMBER PAD */}
            <div className="grid grid-cols-3 gap-4">

              {[1,2,3,4,5,6,7,8,9].map((num) => (
                <button
                  key={num}
                  onClick={() => handleNumber(num.toString())}
                  className="bg-white h-14 rounded-xl text-xl font-semibold hover:scale-105 transition"
                >
                  {num}
                </button>
              ))}

              <button
                onClick={clearPassword}
                className="bg-red-300 h-14 rounded-xl"
              >
                C
              </button>

              <button
                onClick={() => handleNumber("0")}
                className="bg-white h-14 rounded-xl text-xl font-semibold"
              >
                0
              </button>

              <button
                onClick={checkPassword}
                className="bg-pink-500 text-white h-14 rounded-xl"
              >
                OK
              </button>

            </div>

          </div>

        </div>

      ) : (

        <>
          {!envelopeOpened ? (

            <Hero onOpen={() => setEnvelopeOpened(true)} />

          ) : (

            <>
              <Gallery />
              <Message />
              <Surprise onBack={() => setEnvelopeOpened(false)} />
            </>

          )}
        </>

      )}

    </main>
  );
}